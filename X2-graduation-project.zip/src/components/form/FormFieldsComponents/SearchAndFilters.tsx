import React, { useState } from "react";
import type { CTAButton } from "../../../types/Properties/PropertiesTypes";
import SearchSelect from "./SearchSelect";

type SearchSection = {
  searchField: { id: string; placeholder: string; type: string };
  searchButton: CTAButton;
};

type FormField = {
  id: string;
  placeholder: string;
  type: string;
  name: string;
  options?: string[];
  icon?: React.ReactNode;
};

type SearchFilterSection = {
  sectionTitle?: string;
  formFields: FormField[];
  submitButton?: CTAButton;
};

interface Props {
  searchData: SearchSection;
  filterData: SearchFilterSection;
  onSearch?: (criteria: Record<string, string>) => void;
}

const SearchAndFilters: React.FC<Props> = ({ searchData, filterData, onSearch }) => {
  const { searchField, searchButton } = searchData;
  const { formFields } = filterData;
  const [query, setQuery] = useState<string>("");
  const [filters, setFilters] = useState<Record<string, string>>({});

  const handleSelectChange = (id: string, value: string) => {
    setFilters((prev) => ({ ...prev, [id]: value }));
  };

  const handleSearch = () => {
    onSearch?.({ q: query, ...filters });
  };

  const renderButton = (btn: CTAButton) => (
    <button 
      className="flex items-center text-sm lg:text-lg font-medium justify-center gap-2 w-fit lg:w-46 h-[63px] px-5 py-3.5 xl:px-6 xl:py-4.5 rounded-t-[10px] bg-Purple-60 text-white hover:bg-Purple-75 transition"
      onClick={handleSearch}
    >
      {btn.icon && (
        <img
          src={btn.icon.toString()}
          alt="search icon"
          className="w-5 h-5 lg:w-6 lg:h-6"
        />
      )}
      <span className="min-w-max hidden lg:flex text-sm xl:text-lg font-medium ">{btn.text}</span>
    </button>
  );

  return (
    <div className="flex flex-col gap-y-5 lg:gap-y-0 ">
      <div className="mx-auto w-full lg:max-w-[81.45363%]">
        <div className="relative w-full h-[80px] xl:h-[103px]">
          <input
            type={searchField.type}
            id={searchField.id}
            placeholder={searchField.placeholder}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="pl-3.5 md:pl-5 xl:pl-6 w-full h-full text-base md:text-xl rounded-t-xl rounded-bl-0 rounded-br-0 border border-Grey-15 
                    shadow-[0px_0px_0px_4px_var(--color-Grey-10)] lg:shadow-[0px_0px_0px_10px_var(--color-Grey-10)] bg-Grey-08 placeholder:text-Grey-60 focus:outline-none"
          />
          <div className="absolute top-1/2 right-[20px] transform -translate-y-1/2">
            {renderButton(searchButton)}
          </div>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-[10px] p-3.5 rounded-xl bg-Grey-10">
        {formFields
          .filter((field) => field.type === "select")
          .map((field) => (
            <SearchSelect
              key={field.id}
              field={field}
              value={filters[field.id] || ""}
              onChange={handleSelectChange}
            />
          ))}
      </div>
    </div>
  );
};

export default SearchAndFilters;