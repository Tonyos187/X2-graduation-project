// import React, { createContext, useContext, useState, type ReactNode } from 'react';

// // أنواع البيانات
// export interface Property {
//   id: number;
//   title: string;
//   price: string;
//   fullDescription: string;
//   image: string;
//   discoverDescription?: string;
//   details?: Array<{ icon: ReactNode; label: string }>;
//   btnText: string;
//   btnLink: string;
// }

// interface SearchContextType {
//   searchQuery: string;
//   setSearchQuery: (query: string) => void;
//   filters: Record<string, string>;
//   setFilter: (key: string, value: string) => void;
//   searchResults: Property[];
//   performSearch: () => void;
//   hasSearched: boolean;
// }

// const SearchContext = createContext<SearchContextType | undefined>(undefined);

// export const useSearch = () => {
//   const context = useContext(SearchContext);
//   if (!context) {
//     throw new Error('useSearch must be used within a SearchProvider');
//   }
//   return context;
// };

// interface SearchProviderProps {
//   children: ReactNode;
//   allProperties: Property[];
// }

// export const SearchProvider: React.FC<SearchProviderProps> = ({ children, allProperties }) => {
//   const [searchQuery, setSearchQuery] = useState('');
//   const [filters, setFilters] = useState<Record<string, string>>({});
//   const [searchResults, setSearchResults] = useState<Property[]>([]);
//   const [hasSearched, setHasSearched] = useState(false);

//   const setFilter = (key: string, value: string) => {
//     setFilters(prev => ({ ...prev, [key]: value }));
//   };

//   const performSearch = () => {
//     // تطبيق البحث والفلترة
//     let results = [...allProperties];
    
//     // تطبيق البحث النصي
//     if (searchQuery.trim()) {
//       const query = searchQuery.toLowerCase().trim();
//       results = results.filter(property => 
//         property.title.toLowerCase().includes(query) || 
//         property.fullDescription.toLowerCase().includes(query)
//       );
//     }
    
//     // تطبيق الفلاتر
//     Object.entries(filters).forEach(([key, value]) => {
//       if (value) {
//         // هنا يمكنك إضافة منطق التصفية حسب الحقل
//         // هذا مثال مبسط، قد تحتاج إلى تكييفه حسب هيكل بياناتك
//         results = results.filter(property => 
//           // هذا مثال - تحتاج إلى تعديله ليناسب بياناتك الفعلية
//           property.title.toLowerCase().includes(value.toLowerCase())
//         );
//       }
//     });
    
//     setSearchResults(results);
//     setHasSearched(true);
//   };

//   return (
//     <SearchContext.Provider value={{
//       searchQuery,
//       setSearchQuery,
//       filters,
//       setFilter,
//       searchResults,
//       performSearch,
//       hasSearched
//     }}>
//       {children}
//     </SearchContext.Provider>
//   );
// };

import React, { createContext, useContext, useState, type ReactNode } from 'react';

// أنواع البيانات
export interface Property {
  id: number;
  title: string;
  price: string;
  fullDescription: string;
  image: string;
  discoverDescription?: string;
  details?: Array<{ icon: ReactNode; label: string }>;
  btnText: string;
  btnLink: string;
  // إضافة خصائص جديدة للفلترة
  location?: string;
  propertyType?: string;
  bedrooms?: number;
  bathrooms?: number;
  size?: number;
  buildYear?: number;
}

interface SearchContextType {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  filters: Record<string, string>;
  setFilter: (key: string, value: string) => void;
  searchResults: Property[];
  performSearch: () => void;
  hasSearched: boolean;
  clearFilters: () => void;
}

const SearchContext = createContext<SearchContextType | undefined>(undefined);

export const useSearch = () => {
  const context = useContext(SearchContext);
  if (!context) {
    throw new Error('useSearch must be used within a SearchProvider');
  }
  return context;
};

interface SearchProviderProps {
  children: ReactNode;
  allProperties: Property[];
}

export const SearchProvider: React.FC<SearchProviderProps> = ({ children, allProperties }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [searchResults, setSearchResults] = useState<Property[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  const setFilter = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({});
    setSearchQuery('');
  };

  const performSearch = () => {
    // تطبيق البحث والفلترة
    let results = [...allProperties];
    
    // تطبيق البحث النصي (في العنوان، الوصف، والموقع)
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      results = results.filter(property => 
        property.title.toLowerCase().includes(query) || 
        property.fullDescription.toLowerCase().includes(query) ||
        (property.discoverDescription && property.discoverDescription.toLowerCase().includes(query)) ||
        (property.location && property.location.toLowerCase().includes(query))
      );
    }
    
    // تطبيق الفلاتر من selects
    Object.entries(filters).forEach(([key, value]) => {
      if (value) {
        switch(key) {
          case "location":
            results = results.filter(property => 
              property.location && property.location.toLowerCase().includes(value.toLowerCase())
            );
            break;
          
          case "property-type":
            results = results.filter(property => 
              property.propertyType && property.propertyType.toLowerCase() === value.toLowerCase()
            );
            break;
          
          case "price-range":
            // فلترة حسب نطاق السعر
            const priceNum = parseInt(property.price.replace(/[^\d]/g, ''));
            switch(value) {
              case "$100K - $300K":
                results = results.filter(property => priceNum >= 100000 && priceNum <= 300000);
                break;
              case "$300K - $500K":
                results = results.filter(property => priceNum >= 300000 && priceNum <= 500000);
                break;
              case "$500K - $1M":
                results = results.filter(property => priceNum >= 500000 && priceNum <= 1000000);
                break;
              case "$1M+":
                results = results.filter(property => priceNum >= 1000000);
                break;
            }
            break;
          
          case "property-size":
            // فلترة حسب نطاق المساحة
            if (property.size) {
              switch(value) {
                case "500 - 1000 sqft":
                  results = results.filter(property => property.size >= 500 && property.size <= 1000);
                  break;
                case "1000 - 2000 sqft":
                  results = results.filter(property => property.size >= 1000 && property.size <= 2000);
                  break;
                case "2000 - 3000 sqft":
                  results = results.filter(property => property.size >= 2000 && property.size <= 3000);
                  break;
                case "3000+ sqft":
                  results = results.filter(property => property.size >= 3000);
                  break;
              }
            }
            break;
          
          case "build-year":
            // فلترة حسب سنة البناء
            if (property.buildYear) {
              switch(value) {
                case "2020 - Present":
                  results = results.filter(property => property.buildYear >= 2020);
                  break;
                case "2010 - 2020":
                  results = results.filter(property => property.buildYear >= 2010 && property.buildYear <= 2020);
                  break;
                case "2000 - 2010":
                  results = results.filter(property => property.buildYear >= 2000 && property.buildYear <= 2010);
                  break;
                case "1990 - 2000":
                  results = results.filter(property => property.buildYear >= 1990 && property.buildYear <= 2000);
                  break;
              }
            }
            break;
          
          default:
            // فلترة عامة للخواص الأخرى
            results = results.filter(property => 
              property.title.toLowerCase().includes(value.toLowerCase()) ||
              property.fullDescription.toLowerCase().includes(value.toLowerCase())
            );
        }
      }
    });
    
    setSearchResults(results);
    setHasSearched(true);
  };

  return (
    <SearchContext.Provider value={{
      searchQuery,
      setSearchQuery,
      filters,
      setFilter,
      searchResults,
      performSearch,
      hasSearched,
      clearFilters
    }}>
      {children}
    </SearchContext.Provider>
  );
};